<!DOCTYPE html>
<html>
	<head>
		<title>Computer Science Degree Tracker</title>

		<!-- external stylesheet for the whole page -->
		<link rel="stylesheet" href="css/index.css">
	</head>

	<body>
		<h1>Computer Science Degree Tracker</h1>
		<p class="thanks"><?php echo "$first_name $last_name"; ?>, your selections have been submitted. Thank you.</p>
	</body>
</html>